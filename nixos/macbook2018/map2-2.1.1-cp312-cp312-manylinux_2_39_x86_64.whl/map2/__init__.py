from .map2 import *

__doc__ = map2.__doc__
if hasattr(map2, "__all__"):
    __all__ = map2.__all__